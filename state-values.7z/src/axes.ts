let ptnl_array: Array<string> = ['Libertarian', 'Autonomist', 'Centrist', 'Paternalist-Leaning', 'Paternalist']
let stat_array: Array<string> = ['Planned Economy', 'Regulationist', 'Centrist', 'Free-Market', 'Laissez-Faire']
let part_array: Array<string> = ['Partisan', 'Partisan-Leaning', 'Mixture', 'Non-Partisan Leaning', 'Non-Partisan']
let auth_array: Array<string> = ['Autocracy', 'Authoritarian Democracy', 'Mixed Regime', 'Constitutional Democracy', 'Full Democracy']